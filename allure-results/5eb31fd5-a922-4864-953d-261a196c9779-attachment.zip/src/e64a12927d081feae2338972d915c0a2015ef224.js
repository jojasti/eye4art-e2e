// Generated from: features\about.feature
import { test } from "../../fixtures/fixtures.ts";

test.describe('About page', () => {

  test('About page shows its main heading and core values', async ({ Given, Then, And, aboutPage }) => { 
    await Given('I open the about page', null, { aboutPage }); 
    await Then('the main heading is shown', null, { aboutPage }); 
    await And('the value headings are shown', null, { aboutPage }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features\\about.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":3,"tags":[],"steps":[{"pwStepLine":7,"gherkinStepLine":4,"keywordType":"Context","textWithKeyword":"Given I open the about page","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":5,"keywordType":"Outcome","textWithKeyword":"Then the main heading is shown","stepMatchArguments":[]},{"pwStepLine":9,"gherkinStepLine":6,"keywordType":"Outcome","textWithKeyword":"And the value headings are shown","stepMatchArguments":[]}]},
]; // bdd-data-end